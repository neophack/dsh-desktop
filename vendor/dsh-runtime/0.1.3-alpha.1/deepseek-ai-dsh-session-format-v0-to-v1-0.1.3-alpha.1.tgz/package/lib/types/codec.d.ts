import type { EncodedSessionFormatArtifact, SessionFormatArtifact, SessionFormatEncodeOptions, SessionFormatHeader } from '@deepseek-ai/dsh-session-format';
/** Frozen physical JSON codec for the released v0 layout. */
export declare const releasedV0SessionFormatCodec: Readonly<{
    version: 0 | 1;
    decodeHeader: (value: unknown) => SessionFormatHeader;
    decodeArtifact(headerValue: unknown, rowValues: readonly unknown[]): SessionFormatArtifact;
    decodeRecoverableArtifact(headerValue: unknown, rowValues: readonly unknown[]): SessionFormatArtifact;
    encodeArtifact(artifact: SessionFormatArtifact, options: SessionFormatEncodeOptions): EncodedSessionFormatArtifact;
}>;
/** Frozen physical JSON codec for the shared-layout released v1 format. */
export declare const releasedV1SessionFormatCodec: Readonly<{
    version: 0 | 1;
    decodeHeader: (value: unknown) => SessionFormatHeader;
    decodeArtifact(headerValue: unknown, rowValues: readonly unknown[]): SessionFormatArtifact;
    decodeRecoverableArtifact(headerValue: unknown, rowValues: readonly unknown[]): SessionFormatArtifact;
    encodeArtifact(artifact: SessionFormatArtifact, options: SessionFormatEncodeOptions): EncodedSessionFormatArtifact;
}>;
//# sourceMappingURL=codec.d.ts.map